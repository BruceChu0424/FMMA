
module HPSfgpa2 (
	bram_out_address,
	bram_out_chipselect,
	bram_out_clken,
	bram_out_write,
	bram_out_readdata,
	bram_out_writedata,
	bram_out_byteenable,
	clk_clk,
	feed_upd_valid,
	feed_upd_sym,
	feed_upd_side,
	feed_upd_idx,
	feed_upd_delta,
	inventory_position,
	inventory_pos_update,
	memory_mem_a,
	memory_mem_ba,
	memory_mem_ck,
	memory_mem_ck_n,
	memory_mem_cke,
	memory_mem_cs_n,
	memory_mem_ras_n,
	memory_mem_cas_n,
	memory_mem_we_n,
	memory_mem_reset_n,
	memory_mem_dq,
	memory_mem_dqs,
	memory_mem_dqs_n,
	memory_mem_odt,
	memory_mem_dm,
	memory_oct_rzqin,
	quotes_q_valid,
	quotes_q_bid_en,
	quotes_q_ask_en,
	quotes_q_bid,
	quotes_q_ask,
	reset_reset_n);	

	input	[9:0]	bram_out_address;
	input		bram_out_chipselect;
	input		bram_out_clken;
	input		bram_out_write;
	output	[31:0]	bram_out_readdata;
	input	[31:0]	bram_out_writedata;
	input	[3:0]	bram_out_byteenable;
	input		clk_clk;
	input		feed_upd_valid;
	input	[1:0]	feed_upd_sym;
	input		feed_upd_side;
	input	[9:0]	feed_upd_idx;
	input	[31:0]	feed_upd_delta;
	input	[127:0]	inventory_position;
	input	[3:0]	inventory_pos_update;
	output	[12:0]	memory_mem_a;
	output	[2:0]	memory_mem_ba;
	output		memory_mem_ck;
	output		memory_mem_ck_n;
	output		memory_mem_cke;
	output		memory_mem_cs_n;
	output		memory_mem_ras_n;
	output		memory_mem_cas_n;
	output		memory_mem_we_n;
	output		memory_mem_reset_n;
	inout	[7:0]	memory_mem_dq;
	inout		memory_mem_dqs;
	inout		memory_mem_dqs_n;
	output		memory_mem_odt;
	output		memory_mem_dm;
	input		memory_oct_rzqin;
	output	[3:0]	quotes_q_valid;
	output	[3:0]	quotes_q_bid_en;
	output	[3:0]	quotes_q_ask_en;
	output	[39:0]	quotes_q_bid;
	output	[39:0]	quotes_q_ask;
	input		reset_reset_n;
endmodule
